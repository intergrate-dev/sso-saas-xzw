package com.founder.redis;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.json.JSONException;
import org.json.JSONObject;

import com.founder.sso.util.HttpClientUtil;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class JedisClientCluster implements JedisClient{
	
	@Autowired
	private JedisCluster jedisCluster;
	
	//private String serverInfo = "172.30.129.145:7379,172.30.129.145:7380,172.30.129.146:7379,172.30.129.146:7380,172.30.129.147:7379,172.30.129.147:7380";  
	  
    private JedisCluster getClusterInfo() {  
    	String serverInfo = getJedisClusterNodes();
        Set<HostAndPort> set = new HashSet<HostAndPort>();  
        if(serverInfo==null||"".equals(serverInfo.length())) {  
            throw new RuntimeException("The serverInfo can not be empty");  
        }  
        String ipPort[] = serverInfo.split(",");  
        int len = ipPort.length;  
        for(int i=0;i<len;i++) {  
            String server[] = ipPort[i].split(":");  
            set.add(new HostAndPort(server[0], Integer.parseInt(server[1])));  
        }  
        JedisCluster jc = new JedisCluster(set);
        return jc;  
    }
    
    private String getJedisClusterNodes() {  
    	//调用amuc同步接口
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		//params.add(new BasicNameValuePair("",""));
		JSONObject json;
		String REDIS1_ADDR = null;
		String REDIS2_ADDR = null;
		String REDIS3_ADDR = null;
		String res = new HttpClientUtil().callAmucAPI("/api/param/paramConfig.do", params);
		if(res.indexOf("REDIS1_ADDR") == -1){
			return "";
		}
		try {
			json = new JSONObject(res);
			REDIS1_ADDR = json.getString("REDIS1_ADDR");
			REDIS2_ADDR = json.getString("REDIS2_ADDR");
			REDIS3_ADDR = json.getString("REDIS3_ADDR");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		String clusterNodes = REDIS1_ADDR+":7000,"+REDIS2_ADDR+":7001,"+REDIS3_ADDR+":7002,"+REDIS3_ADDR+":7003,"+REDIS1_ADDR+":7004,"+REDIS2_ADDR+":7005";
		System.out.println("------------------clusterNodes-----------"+clusterNodes);
		return clusterNodes;
    }
    

	@Override
	public void set(String key, String value, int expireTime) {
		if(getJedisClusterNodes()==null||"".equals(getJedisClusterNodes())){
			jedisCluster.set(key, value);
			jedisCluster.expire(key, expireTime);
		}else{
			getClusterInfo().set(key, value);
			getClusterInfo().expire(key, expireTime);
		}
	}
	
	@Override
	public String get(String key) {
		if(getJedisClusterNodes()==null||"".equals(getJedisClusterNodes())){
			return jedisCluster.get(key);
		}else{
			return getClusterInfo().get(key);
		}
	}
	
	@Override
	public boolean exists(String key) {
		if(getJedisClusterNodes()==null||"".equals(getJedisClusterNodes())){
			return jedisCluster.exists(key);
		}else{
			return getClusterInfo().exists(key);
		}
	}
	
	@Override
	public long del(String key){
		if(getJedisClusterNodes()==null||"".equals(getJedisClusterNodes())){
			return jedisCluster.del(key);
		}else{
			return getClusterInfo().del(key);
		}
	}
	
	
	public JedisClientCluster() {
		System.out.println("这是redis集群版");
	}
}
