package com.founder.sso.util.securityCode;

import java.awt.image.BufferedImage; 
import java.io.IOException;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.servlet.ServletException; 
import javax.servlet.ServletOutputStream; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.octo.captcha.service.CaptchaServiceException;
import org.springframework.beans.factory.annotation.Autowired;

@SuppressWarnings("serial") 
public class JcaptchaServlet extends HttpServlet { 
    public static final String CAPTCHA_IMAGE_FORMAT = "jpeg"; 
   
    private static final Logger log = Logger.getLogger(JcaptchaServlet.class);



    @Override 
    public void init() throws ServletException { 
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        System.out.println("enter JcaptchaServlet doGet ....");
        response.setHeader("Cache-Control", "no-store, no-cache");
        response.setContentType("image/jpeg");

        //获取图片验证码
        if(StringUtils.isBlank(uuid)){
            throw new RRException("uuid不能为空");
        }
        //生成文字验证码
        String code = producer.createText();

        SysCaptchaEntity captchaEntity = new SysCaptchaEntity();
        captchaEntity.setUuid(uuid);
        captchaEntity.setCode(code);
        //5分钟后过期
        captchaEntity.setExpireTime(DateUtils.addDateMinutes(new Date(), 5));
        this.insert(captchaEntity);

        BufferedImage image = producer.createImage(code);

        ServletOutputStream out = response.getOutputStream();
        ImageIO.write(image, "jpg", out);
        IOUtils.closeQuietly(out);
        System.out.println("quit JcaptchaServlet doGet ....");
    }

    /**
     * @step1 本方法使用Jcaptcha工具生成img图片，并输出到客户端
     * @step2 将来在用户提交的action中插入下面语句进行验证码的校验：Boolean isResponseCorrect =
     *        captchaService.validateResponseForID( captchaId, "");
     **/ 
    //@Override
    protected void doGet1(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        System.out.println("enter JcaptchaServlet doGet ....");
        byte[] captchaChallengeAsJpeg = null;
        ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream(); 
        try { 
            // 借助于HttpSession ID存储Captcha ID，开发者也可以借助于其他惟一值 
            String captchaId = request.getSession().getId();
            BufferedImage image = producer.createImage(code);

            ServletOutputStream out = response.getOutputStream();
            ImageIO.write(image, "jpg", out);
            IOUtils.closeQuietly(out);


            // 获得GMailEngine使用的图片内容 
            /*BufferedImage challenge = JCaptchaServiceSingleton.getInstance().getImageChallengeForID(captchaId, request.getLocale());
            ImageIO.write(challenge, "jpg", jpegOutputStream);*/
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            log.error(e); 
            response.sendError(HttpServletResponse.SC_NOT_FOUND); 
            return; 
        } catch (CaptchaServiceException e) {
            e.printStackTrace();
            log.error(e); 
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); 
            return; 
        }

        try {
            captchaChallengeAsJpeg = jpegOutputStream.toByteArray();
            response.setHeader("Cache-Control", "no-store");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            // 输出JPEG图片
            response.setContentType("image/jpeg");
            ServletOutputStream responseOutputStream = response.getOutputStream();
            responseOutputStream.write(captchaChallengeAsJpeg);
            responseOutputStream.flush();
            responseOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("quit JcaptchaServlet doGet ....");
    }
}
