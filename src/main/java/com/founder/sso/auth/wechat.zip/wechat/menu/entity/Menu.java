package com.founder.sso.auth.wechat.menu.entity;

/**
 * 菜单
 * 
 * @author hanpt
 */
public class Menu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}