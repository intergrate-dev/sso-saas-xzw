/*
package com.founder.sso.auth.wechat.test;

import com.founder.sso.auth.wechat.entity.AccessToken;
import com.founder.sso.auth.wechat.util.WeiXinConstant;
import com.founder.sso.auth.wechat.util.WeiXinUtil;
*/
/**
 * 权限获取测试类
 * @author hanpt
 *
 *//*

public class TokenTest {

	public static void main(String[] args) {
		//获取accessToken
		AccessToken sccessToken = new AccessToken();
		sccessToken = WeiXinUtil.getAccessToken(WeiXinConstant.appID, WeiXinConstant.appsecret);
		System.out.println(sccessToken.getToken());
		System.out.println(sccessToken.getExpiresIn());
	}
}
*/
