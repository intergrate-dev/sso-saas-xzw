/*
package com.founder.sso.auth.wechat.test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.founder.webbase.entity.booknet.BookNetCatalog;
import com.founder.sso.auth.wechat.entity.AccessToken;
import com.founder.sso.auth.wechat.menu.entity.Button;
import com.founder.sso.auth.wechat.menu.entity.CommonButton;
import com.founder.sso.auth.wechat.menu.entity.ComplexButton;
import com.founder.sso.auth.wechat.menu.entity.Menu;
import com.founder.sso.auth.wechat.util.TokenThread;
import com.founder.sso.auth.wechat.util.WeiXinConstant;
import com.founder.sso.auth.wechat.util.WeiXinUtil;

*/
/**
 * 菜单测试类
 * 
 * @author hanpt
 *//*

public class MenuTest {
	
	private static Log log = LogFactory.getLog(MenuTest.class);
	
	public static void main(String[] args) {
		// 将菜单对象转换成json字符串
		String jsonMenu = JSONObject.fromObject(getMenu()).toString();
		System.out.println(jsonMenu);

		// 调用接口获取access_token
		AccessToken sccessToken = new AccessToken();
		sccessToken = WeiXinUtil.getAccessToken(WeiXinConstant.appID, WeiXinConstant.appsecret);
		System.out.println(sccessToken.getToken());
		System.out.println(sccessToken.getExpiresIn());
		if (null != sccessToken) {
			// 调用接口创建菜单
			int result = WeiXinUtil.createMenu(getMenu(), sccessToken.getToken());

			// 判断菜单创建结果
			if (0 == result)
				log.info("菜单创建成功！");
			else
				log.info("菜单创建失败，错误码：" + result);
		}
	}

	*/
/**
	 * 组装菜单数据
	 * 
	 * @return
	 *//*

	private static Menu getMenu() {
		CommonButton mainBtn1 = new CommonButton();
		mainBtn1.setName("字典");
		mainBtn1.setType("click");
		mainBtn1.setKey("V1001_DICT");
		
		CommonButton mainBtn2 = new CommonButton();
		mainBtn2.setName("融入");
		mainBtn2.setType("view");
		String url2=getAuthorizationUrl1();
		mainBtn2.setUrl(url2);
		
		
		CommonButton btn31 = new CommonButton();
		btn31.setName("我的文本");
		btn31.setType("view");
		String url31 = getAuthorizationUrl2();
		btn31.setUrl(url31);
		
		CommonButton btn32 = new CommonButton();
		btn32.setName("我的街拍");
		btn32.setType("view");
		String url32 = getAuthorizationUrl3();
		btn32.setUrl(url32);
		
		ComplexButton mainBtn3 = new ComplexButton();
		mainBtn3.setName("足迹");
		mainBtn3.setSub_button(new CommonButton[] { btn31, btn32 });

		Menu menu = new Menu();
		menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

		return menu;
	}
	
	private static String getAuthorizationUrl1(){
		String url =WeiXinUtil.getAuthorizationCode(WeiXinConstant.appID,"http://59.108.109.216/books_publishsite/weixindict/weixin-dict!index.action",WeiXinConstant.SCOPE_SNSAPI_BASE);
		log.info("自定义菜单融入的链接地址");
		log.info(url);
		return url;
	}
	private static String getAuthorizationUrl2(){
		String url =WeiXinUtil.getAuthorizationCode(WeiXinConstant.appID,"http://59.108.109.216/books_publishsite/weixindict/weixin-dict-footprints.action?type=text",WeiXinConstant.SCOPE_SNSAPI_BASE);
		log.info("自定义菜单我的文本的链接地址");
		log.info(url);
		return url;
	}
	private static String getAuthorizationUrl3(){
		String url =WeiXinUtil.getAuthorizationCode(WeiXinConstant.appID,"http://59.108.109.216/books_publishsite/weixindict/weixin-dict-footprints.action?type=street",WeiXinConstant.SCOPE_SNSAPI_BASE);
		log.info("自定义菜单我的街拍的链接地址");
		log.info(url);
		return url;
	}
}
*/
