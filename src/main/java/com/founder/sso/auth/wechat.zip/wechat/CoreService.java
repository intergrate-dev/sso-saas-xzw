/*
package com.founder.sso.auth.wechat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springside.modules.web.struts2.Struts2Utils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.founder.web.service.MemberService;
import com.founder.web.service.member.MemberScoreService;
import com.founder.web.service.member.MemberTeacherService;
import com.founder.sso.auth.wechat.entity.Article;
import com.founder.sso.auth.wechat.entity.TextMessage;
import com.founder.sso.auth.wechat.util.MessageUtil;
import com.founder.sso.auth.wechat.util.TokenThread;
import com.founder.sso.auth.wechat.util.WeiXinUtil;


*/
/**
 * 核心服务类
 * @author hanpt
 *
 *//*

public class CoreService {
	
	private static final Log log = LogFactory.getLog(CoreService.class);
	
	@Autowired
	private MemberService memberTeacherService = new MemberService();
	@Autowired
	private MemberScoreService memberScoreService = new MemberScoreService();
	*/
/**
	 * 处理微信发来的请求
	 * 
	 * @param request
	 * @return
	 *//*

	public static String processRequest(HttpServletRequest request,HttpServletResponse response) {
		String respMessage = null;
		try {
			// 默认返回的文本消息内容
			String respContent = "这里是《英汉大词典》的官方订阅号，" +
					"为您提供英译汉、汉译英的在线查询功能，" +
					"并诚邀您参与“读者贡献计划”，" +
					"为更新和完善词典，贡献一份力量！";
			JSONObject json = new JSONObject();
			// xml请求解析
			Map<String, String> requestMap = MessageUtil.parseXml(request);

			// 发送方帐号（open_id）
			String fromUserName = requestMap.get("FromUserName");
			log.info("fromUserName  "+fromUserName);
			JSONObject jsonObject = WeiXinUtil.getUserInfo(TokenThread.accessToken.getToken(),fromUserName);
			MemberService.usersProcessingForWeiXin(fromUserName,jsonObject);
			// 公众帐号
			String toUserName = requestMap.get("ToUserName");
			// 消息类型
			String msgType = requestMap.get("MsgType");
			log.info("msgType  "+msgType);
			// 事件类型
			String eventType = requestMap.get("Event");
			log.info("eventType  "+eventType);
			// 回复文本消息
			TextMessage textMessage = new TextMessage();
			textMessage.setToUserName(fromUserName);
			textMessage.setFromUserName(toUserName);
			textMessage.setCreateTime(new Date().getTime());
			textMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);
			textMessage.setFuncFlag(0);
			
			if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_EVENT)) {
				if (eventType.equals(MessageUtil.EVENT_TYPE_CLICK)) {
					String eventKey = requestMap.get("EventKey");
					log.info("eventKey  "+eventKey);
					if (eventKey.equals("V1001_DICT")) {//字典
						respContent = "正在拼命开发中，敬请期待！";
					}else if(eventKey.equals("V2001_INTEGRATION")){//融入
						respContent = "正在拼命开发中，敬请期待！";
					}else if(eventKey.equals("V3001_FOOTPRINTS_TEXT")){//我的文本
						respContent = "正在拼命开发中，敬请期待！";
					}else if(eventKey.equals("V3002_FOOTPRINTS_STREET")){//我的街拍
						respContent = "正在拼命开发中，敬请期待！";
					}
			       
				}
			}
			textMessage.setContent(respContent);
			respMessage = MessageUtil.textMessageToXml(textMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return respMessage;
	}
	
	

	public String getOperateKey(String xmlStr){
		String str = "";
		try{
			StringReader strReader = new StringReader(xmlStr);
	        InputSource is = new InputSource(strReader);
			DocumentBuilderFactory domfac = DocumentBuilderFactory.newInstance();
		    DocumentBuilder dombuilder = domfac.newDocumentBuilder();
			Document doc = dombuilder.parse(is);
			Element root = doc.getDocumentElement();
			NodeList books = root.getChildNodes();
			
			for (int i = 0; i < books.getLength(); i++) {
		        Node book = books.item(i);
		        String pname=book.getNodeName();
		        if("EventKey".equals(pname)){
		        	//TODO str = book.getTextContent();
		        }
			}
		}catch (Exception e) {
			log.error("getOperateKey，获取EventKet失败！", e);
		}
		return str;
	}
	
	
	
	public static JSONObject getNews(String fromUserName){
		List<Article> articleList = new ArrayList<Article>();
		JSONObject json = new JSONObject();
		
		Article article1 = new Article();  
        article1.setTitle("新疆青少年出版社两种图书获 第二届湖北出版政府奖");  
        article1.setDescription("");  
        article1.setPicUrl("http://49.4.132.165/pub/data/attachement/piclinks/site27/20140325/1395748217546.jpg");  
        article1.setUrl("http://49.4.132.165/news/newsdetail.jsp?id=33959&nodeid=1717");  

        Article article2 = new Article();  
        article2.setTitle("习近平:中国既要自己过好 也让别人过好");  
        article2.setDescription("");  
        article2.setPicUrl("http://49.4.132.165/pub/data/attachement/piclinks/site27/20140613/1402650294801.jpg");  
        article2.setUrl("http://49.4.132.165/news/newsdetail.jsp?id=34375&nodeid=1717");  


        articleList.add(article1);  
        articleList.add(article2);  
        json.put("touser", fromUserName);
        json.put("msgtype","news" );
        JSONObject news = new JSONObject();
        JSONArray articles = new JSONArray();
        for(Article article:articleList){
        	JSONObject js = new JSONObject();
        	js.put("title", article.getTitle());
        	js.put("description", article.getDescription());
        	js.put("url", article.getUrl());
        	js.put("picurl", article.getPicUrl());
        	articles.add(js);
        }
        news.put("articles", articles);
        json.put("news", news);
        
		return json;
	}
	
	
	
	
	
	public  void check(HttpServletRequest request,HttpServletResponse response) throws IOException{
		Map map=request.getParameterMap();
	    Set keSet=map.entrySet();
	    for(Iterator itr=keSet.iterator();itr.hasNext();){
	        Map.Entry me=(Map.Entry)itr.next();
	        Object ok=me.getKey();
	        Object ov=me.getValue();
	        String[] value=new String[1];
	        if(ov instanceof String[]){
	            value=(String[])ov;
	        }else{
	            value[0]=ov.toString();
	        }
	        for(int k=0;k<value.length;k++){
	            System.out.println(ok+" = "+value[k]);
	        }
	      }
		//获取操作事件
	    StringBuilder xmlStr = new StringBuilder();
		BufferedReader br=null;
		try {
			br = new BufferedReader(new InputStreamReader(request.getInputStream(),"UTF-8"));
			String line = null;
			while ((line = br.readLine()) != null) {
				xmlStr.append(line);
			}
		}catch (Exception e) {
			log.error("outError", e);
		}finally{
			if(br!=null){
				br.close();
			}
		}
		System.out.println("DATA  "+ xmlStr.toString());
		if(xmlStr!=null){
			String oper = getOperateKey(xmlStr.toString());
			System.out.println("操作        "+oper);
		}
		String msg = "";
		*/
/*log.info("**********微信端口验证开始**********");
		String signature = Struts2Utils.getParameter("signature");
		log.info("signature:"+signature);
		String timestamp = Struts2Utils.getParameter("timestamp");
		log.info("timestamp:"+timestamp);
		String nonce = Struts2Utils.getParameter("nonce");
		log.info("nonce:"+nonce);*//*

		String echostr = Struts2Utils.getParameter("echostr");
		log.info("echostr:"+echostr);
		msg = echostr;
		out(response, msg);
		log.info("**********微信端口验证结束**********");
	}
	
	
	public static void out(HttpServletResponse response, String msg) {
		try {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.print(msg);
		} catch (IOException e) {
			log.error("outError", e);
		}
	}
	
	
}*/
