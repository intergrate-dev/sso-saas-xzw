/*
package com.founder.sso.auth.wechat.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springside.modules.web.struts2.Struts2Utils;

import com.founder.web.action.CrudActionSupport;
import com.founder.sso.auth.wechat.CoreService;
import com.founder.sso.auth.wechat.util.WeiXinUtil;

@Namespace("/weixin")
@Results({ @Result(name = CrudActionSupport.RELOAD, location = "weixin-info-client.action", type = "redirect") })
public class WeixinInfoClientAction extends CrudActionSupport<Object> {

	private static final long serialVersionUID = 106L;
	private static final Log log = LogFactory.getLog(WeixinInfoClientAction.class);
	private String url;
	private String jsonstr;

	public Object getModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String list() throws Exception {
		log.info("**********微信端口验证开始**********");
		HttpServletRequest request = Struts2Utils.getRequest();
		HttpServletResponse response = Struts2Utils.getResponse();
		String content = CoreService.processRequest(request,response);
		if(content!=null&&!"".equals(content)&&!"{}".equals(content)){
			WeiXinUtil.sendNews(content);
		}else{
			log.info("**********没有数据，不向微信服务器发送。**********");
		}
		log.info("**********微信端口验证结束**********");
		return null;
	}
	@Override
	public String input() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String save() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String delete() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void prepareModel() throws Exception {

	}

	
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getJsonstr() {
		return jsonstr;
	}

	public void setJsonstr(String jsonstr) {
		this.jsonstr = jsonstr;
	}

}
*/
