package com.founder.sso.auth.wechat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.founder.sso.auth.wechat.util.TokenThread;
import com.founder.sso.auth.wechat.util.WeiXinConstant;
import com.founder.sso.auth.wechat.util.WeiXinUtil;

/**
 * 初始化权限获取
 * @author hanpt
 *
 */
public class InitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(InitServlet.class);
	public void init() throws ServletException {
		log.info("weixin api appid:{}", WeiXinConstant.appID);
		log.info("weixin api appsecret:{}", WeiXinConstant.appsecret);
		if ("".equals(WeiXinConstant.appID) || "".equals(WeiXinConstant.appsecret)) {
			log.error("微信获取accessToken时 ，appid 和  appsecret无效。");
		} else {
			// 启动定时获取access_token的线程
			
			//new Thread(new TokenThread()).start();
		}
	}
}