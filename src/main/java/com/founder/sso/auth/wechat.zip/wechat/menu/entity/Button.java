package com.founder.sso.auth.wechat.menu.entity;

/**
 * 按钮的基类
 * 
 * @author hanpt
 */
public class Button {
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
