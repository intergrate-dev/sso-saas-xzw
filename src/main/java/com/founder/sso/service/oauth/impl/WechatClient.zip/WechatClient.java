package com.founder.sso.service.oauth.impl;

import javax.servlet.ServletRequest;

import com.founder.sso.admin.utils.Encodes;
import com.founder.sso.service.oauth.OauthClient;
import com.founder.sso.service.oauth.OauthClientManager;
import com.founder.sso.service.oauth.entity.OauthAccessToken;
import com.founder.sso.service.oauth.entity.OauthErrorMsg;
import com.founder.sso.service.oauth.entity.OauthProviders;
import com.founder.sso.service.oauth.entity.RemoteUser;
import com.founder.sso.util.WebUtil;
import com.founder.sso.util.http.HttpClient;
import com.founder.sso.util.http.PostParameter;
import com.founder.sso.util.http.Response;

public class WechatClient extends OauthClient {
    public final String provider = OauthProviders.TENCENT_WECHAT.getValue();
    public final String providerName = OauthProviders.TENCENT_WECHAT.getName();
    private final String[] accessTokenAttrNames = { "access_token", "expires_in", "refresh_token", "openid" };
    private final String[] remoteUserAttrName = { "unionid", "nickname", "headimgurl" };
    private HttpClient client = new HttpClient();

    @Override
    public String getProvider() {
        return provider;
    }

    @Override
    public String getProviderName() {
        return providerName;
    }

    @Override
    public String getAuthorizeUrl() {
        return "https://open.weixin.qq.com/connect/qrconnect?appid=" + config.getAppId() + "&redirect_uri="
                + Encodes.urlEncode(OauthClientManager.getAuthCallbackUrl(getProvider())) + "&response_type=code&scope=snsapi_login";
    }

	@Override
	public String getBindingUrl() {
		 return "https://open.weixin.qq.com/connect/qrconnect?appid=" + config.getAppId() + "&redirect_uri="
	                + Encodes.urlEncode(OauthClientManager.getAuthCallbackUrlBinding(getProvider())) + "&response_type=code&scope=snsapi_login";
	    
	}
	
    @Override
    public OauthErrorMsg detectErrorMsg(ServletRequest request) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String parseAuthcCode(ServletRequest request) {
        return WebUtil.getFirstValue(request, "code");
    }

    @Override
    public OauthAccessToken exchangeAccessToken(String authcCode) throws OauthErrorMsg {
        OauthAccessToken accessToken = null;
        String exchangeUrl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + config.getAppId() + "&secret=" + config.getSecretKey() + "&code="
                + authcCode + "&grant_type=authorization_code";

        try {
            Response resp = client.post(exchangeUrl, new PostParameter[0], false, null);
            accessToken = new OauthAccessToken(resp.asJSONObject(), accessTokenAttrNames);
            accessToken.setProvider(getProvider());
        } catch (Exception e) {
            throw new OauthErrorMsg();
        }
        return accessToken;
    }
    
    @Override
    public OauthAccessToken exchangeAccessTokenForBinding(String authcCode) throws OauthErrorMsg {
    	return exchangeAccessToken(authcCode);
    }
    @Override
    public RemoteUser fetchRemoteUser(OauthAccessToken accessToken) {
        RemoteUser user = null;
        String fetchUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=" + accessToken.getAccessToken() + "&openid=" + accessToken.getUid();
        try {
            // TODO 抽象共有的Json转换模块
            Response response = client.post(fetchUrl, new PostParameter[0],false, null);
            user = new RemoteUser(response.asJSONObject(), remoteUserAttrName);
            user.setAccessToken(accessToken.getAccessToken());
            user.setTokenExpiresTime(accessToken.getTokenExpiresTime());
            user.setProvider(getProvider());
        } catch (Exception e) {
            throw new OauthErrorMsg();
        }
        return user;
    }

    @Override
    public RemoteUser getRemoteUser(ServletRequest request) {
        return null;
    }


}
